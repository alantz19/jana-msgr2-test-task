module.exports = {
  plugins: {
    tailwindcss: { config: './src/css/tailwind.config.js' },
    autoprefixer: {},
  },
}